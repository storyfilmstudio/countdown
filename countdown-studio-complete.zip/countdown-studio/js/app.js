/**
 * COUNTDOWN STUDIO - Master Application Logic
 * Standalone, browser-based professional countdown video creator.
 * Features:
 *  - Accurate mathematical frame-based countdown timeline (zero drift)
 *  - 10 distinct visual templates (Luxury Gold, Royal Blue, Neon Pink, LED 7-Segment, etc.)
 *  - Independent background management with dedicated Chroma Key Green (#00FF00)
 *  - Real-time (1:1) and Compressed/Custom duration video generation modes
 *  - Native resolution support (1920x1080, 1280x720, 1080x1920, 1080x1080) @ 30/60 FPS
 *  - MediaRecorder encoding (genuine MP4 where supported, or WebM)
 *  - Persistent Blob memory allowing unlimited repeated downloads of the same video
 *  - Full Project ZIP download support without external libraries
 */

// Global Application State
const state = {
  // Timer Settings
  startSeconds: 180, // Default 3 minutes
  timeString: '03:00',
  durationMode: 'compressed', // 'realtime' or 'compressed'
  outputDuration: 10, // Output video length in seconds for compressed mode

  // Template & Aesthetics
  template: 'gold', // gold, blue, pink, red, chrome, purple, green, led, minimal, glass
  bgColor: '#00ff00', // Default Chroma Key Green for professional video editing
  isChromaPreset: true,
  numColor: '', // Empty = use template default
  frameColor: '',
  glowColor: '',
  fontFamily: "'Montserrat', sans-serif",
  fontScale: 1.0,
  frameThickness: 8,
  cornerRadius: 24,
  glowIntensity: 1.0,
  position: 'center', // 'center', 'lower-third', 'top', 'bottom'

  // Sound & Audio Settings
  soundEnabled: true,
  soundEffect: 'tick', // 'tick', 'beep', 'click', 'pulse', 'final_beep', 'silent'
  soundVolume: 0.8, // 0.0 to 1.0

  // Video Output Configuration
  resolution: { width: 1920, height: 1080, name: '1920x1080' },
  fps: 30,

  // Live Preview Control
  previewPlaying: true,
  previewTime: 0, // In seconds (0 to current duration)
  lastPreviewTimestamp: 0,
  lastPreviewSec: -1,

  // Generation & Recording State
  isGenerating: false,
  isCancelled: false,
  generationProgress: 0,
  currentVideoBlob: null,
  currentVideoUrl: null,
  currentMimeType: '',
  currentFileExt: 'webm',
  videoFileSize: ''
};

// ---------------------------------------------------------------------------
// 7-Segment LED Vector Tables
// ---------------------------------------------------------------------------
// Segments: 0: top, 1: top-right, 2: bottom-right, 3: bottom, 4: bottom-left, 5: top-left, 6: middle
const LED_SEGMENTS = {
  '0': [1, 1, 1, 1, 1, 1, 0],
  '1': [0, 1, 1, 0, 0, 0, 0],
  '2': [1, 1, 0, 1, 1, 0, 1],
  '3': [1, 1, 1, 1, 0, 0, 1],
  '4': [0, 1, 1, 0, 0, 1, 1],
  '5': [1, 0, 1, 1, 0, 1, 1],
  '6': [1, 0, 1, 1, 1, 1, 1],
  '7': [1, 1, 1, 0, 0, 0, 0],
  '8': [1, 1, 1, 1, 1, 1, 1],
  '9': [1, 1, 1, 1, 0, 1, 1]
};

// ---------------------------------------------------------------------------
// Time Parsing & Calculation Utility Functions
// ---------------------------------------------------------------------------
function parseTimeString(str) {
  if (typeof str !== 'string') return NaN;
  const value = str.trim();
  if (!value) return NaN;

  const parts = value.split(':');
  if (parts.length < 1 || parts.length > 3 || parts.some(part => !/^\d+$/.test(part))) {
    return NaN;
  }

  const nums = parts.map(part => Number(part));
  if (nums.some(number => !Number.isSafeInteger(number) || number < 0)) return NaN;

  if (parts.length === 1) return nums[0];
  if (parts.length === 2) {
    const [minutes, seconds] = nums;
    if (seconds > 59) return NaN;
    return minutes * 60 + seconds;
  }

  const [hours, minutes, seconds] = nums;
  if (minutes > 59 || seconds > 59) return NaN;
  return hours * 3600 + minutes * 60 + seconds;
}

function formatSecondsToDisplay(sec, forceHours = false) {
  const s = Math.max(0, Math.floor(sec));
  const hrs = Math.floor(s / 3600);
  const mins = Math.floor((s % 3600) / 60);
  const secs = s % 60;

  const mm = String(mins).padStart(2, '0');
  const ss = String(secs).padStart(2, '0');

  if (hrs > 0 || forceHours) {
    const hh = String(hrs).padStart(2, '0');
    return `${hh}:${mm}:${ss}`;
  }
  return `${mm}:${ss}`;
}

/**
 * Calculates remaining countdown time based on exact video timestamp.
 * Avoids any timer drift, guarantees frame 0 is start time and final frame is 00:00.
 */
function calculateRemainingTime(videoElapsedSec, totalVideoDurationSec, totalStartSec) {
  if (totalVideoDurationSec <= 0) return 0;
  const progress = Math.min(1, Math.max(0, videoElapsedSec / totalVideoDurationSec));

  if (progress >= 1.0) {
    return 0;
  }
  if (progress <= 0) {
    return totalStartSec;
  }

  // Exact linear descent from start to 0
  const remainingFloat = totalStartSec * (1.0 - progress);
  return Math.max(0, Math.ceil(remainingFloat - 1e-7));
}

function formatBytes(bytes) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// ---------------------------------------------------------------------------
// Web Audio API Sound Synthesis Engine (Zero external files, pure synthesis)
// ---------------------------------------------------------------------------
let sharedAudioContext = null;

function getAudioContext() {
  if (!sharedAudioContext) {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (AudioContextClass) {
      sharedAudioContext = new AudioContextClass();
    }
  }
  if (sharedAudioContext && sharedAudioContext.state === 'suspended') {
    sharedAudioContext.resume().catch(() => {});
  }
  return sharedAudioContext;
}

/**
 * Synthesizes a realistic analog clock tick.
 * Crisp transient high-pass noise burst + wood-body resonant decay.
 */
function playClockTickSound(ctx, destination, startTime, volume = 0.8) {
  const t = startTime;

  // 1. Transient click
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = 'triangle';
  osc.frequency.setValueAtTime(1200, t);
  osc.frequency.exponentialRampToValueAtTime(300, t + 0.018);

  gain.gain.setValueAtTime(volume * 0.9, t);
  gain.gain.exponentialRampToValueAtTime(0.001, t + 0.022);

  osc.connect(gain);
  gain.connect(destination);

  osc.start(t);
  osc.stop(t + 0.025);

  // 2. High-pass noise snap
  try {
    const bufferSize = Math.floor(ctx.sampleRate * 0.015);
    const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }

    const noise = ctx.createBufferSource();
    noise.buffer = noiseBuffer;

    const filter = ctx.createBiquadFilter();
    filter.type = 'highpass';
    filter.frequency.setValueAtTime(2200, t);

    const noiseGain = ctx.createGain();
    noiseGain.gain.setValueAtTime(volume * 0.5, t);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, t + 0.015);

    noise.connect(filter);
    filter.connect(noiseGain);
    noiseGain.connect(destination);

    noise.start(t);
    noise.stop(t + 0.016);
  } catch (e) {}
}

/**
 * Synthesizes an electronic digital beep.
 */
function playDigitalBeepSound(ctx, destination, startTime, volume = 0.8, freq = 1200, duration = 0.05) {
  const t = startTime;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = 'sine';
  osc.frequency.setValueAtTime(freq, t);

  gain.gain.setValueAtTime(0, t);
  gain.gain.linearRampToValueAtTime(volume * 0.8, t + 0.003);
  gain.gain.exponentialRampToValueAtTime(0.001, t + duration);

  osc.connect(gain);
  gain.connect(destination);

  osc.start(t);
  osc.stop(t + duration + 0.005);
}

/**
 * Synthesizes a soft, subtle UI click.
 */
function playSoftClickSound(ctx, destination, startTime, volume = 0.8) {
  const t = startTime;
  const osc = ctx.createOscillator();
  const filter = ctx.createBiquadFilter();
  const gain = ctx.createGain();

  osc.type = 'sine';
  osc.frequency.setValueAtTime(500, t);
  osc.frequency.exponentialRampToValueAtTime(180, t + 0.02);

  filter.type = 'lowpass';
  filter.frequency.setValueAtTime(1400, t);

  gain.gain.setValueAtTime(volume * 0.7, t);
  gain.gain.exponentialRampToValueAtTime(0.001, t + 0.025);

  osc.connect(filter);
  filter.connect(gain);
  gain.connect(destination);

  osc.start(t);
  osc.stop(t + 0.028);
}

/**
 * Synthesizes a cinematic sub-bass heartbeat pulse.
 */
function playCinematicPulseSound(ctx, destination, startTime, volume = 0.8) {
  const t = startTime;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  const filter = ctx.createBiquadFilter();

  osc.type = 'sine';
  osc.frequency.setValueAtTime(85, t);
  osc.frequency.exponentialRampToValueAtTime(42, t + 0.26);

  filter.type = 'lowpass';
  filter.frequency.setValueAtTime(320, t);

  gain.gain.setValueAtTime(0.01, t);
  gain.gain.linearRampToValueAtTime(volume * 0.95, t + 0.02);
  gain.gain.exponentialRampToValueAtTime(0.001, t + 0.28);

  osc.connect(filter);
  filter.connect(gain);
  gain.connect(destination);

  osc.start(t);
  osc.stop(t + 0.3);
}

/**
 * Synthesizes the triumphant celebratory chord at 00:00.
 * Major triad arpeggio (C5, E5, G5, C6) with golden bell resonance.
 */
function playTriumphantChime(ctx, destination, startTime, volume = 0.8) {
  const notes = [
    { freq: 523.25, offset: 0.0, dur: 1.4, vol: 0.8 },  // C5
    { freq: 659.25, offset: 0.05, dur: 1.35, vol: 0.7 }, // E5
    { freq: 783.99, offset: 0.1, dur: 1.3, vol: 0.85 },  // G5
    { freq: 1046.5, offset: 0.16, dur: 1.6, vol: 0.9 }   // C6
  ];

  notes.forEach(n => {
    const t = startTime + n.offset;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(n.freq, t);

    gain.gain.setValueAtTime(0.001, t);
    gain.gain.linearRampToValueAtTime(volume * n.vol, t + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.001, t + n.dur);

    osc.connect(gain);
    gain.connect(destination);

    osc.start(t);
    osc.stop(t + n.dur + 0.05);
  });
}

/**
 * Universal sound dispatcher supporting both preview and recording streams.
 */
function playSynthesizedSound(effect, opts = {}) {
  if (!state.soundEnabled || effect === 'silent') return;
  const ctx = getAudioContext();
  if (!ctx) return;

  const vol = (opts.volume !== undefined ? opts.volume : state.soundVolume);
  if (vol <= 0) return;

  const dest = opts.destination || ctx.destination;
  const now = ctx.currentTime;
  const isFinal = opts.isFinalChime || false;

  if (isFinal) {
    playTriumphantChime(ctx, dest, now, vol);
    return;
  }

  switch (effect) {
    case 'tick':
      playClockTickSound(ctx, dest, now, vol);
      break;
    case 'beep':
      playDigitalBeepSound(ctx, dest, now, vol, 1200, 0.05);
      break;
    case 'click':
      playSoftClickSound(ctx, dest, now, vol);
      break;
    case 'pulse':
      playCinematicPulseSound(ctx, dest, now, vol);
      break;
    case 'final_beep':
      playDigitalBeepSound(ctx, dest, now, vol, 1400, 0.075);
      break;
    default:
      playClockTickSound(ctx, dest, now, vol);
  }
}

/**
 * Plays a single sample of the currently selected sound effect.
 */
function previewSingleSound() {
  getAudioContext();
  if (!state.soundEnabled || state.soundEffect === 'silent') {
    showToast('Sound is currently muted or set to Silent.');
    return;
  }
  playSynthesizedSound(state.soundEffect, { volume: state.soundVolume });
}

/**
 * Plays a test sequence simulating 3... 2... 1... 00:00!
 */
function testCountdownAudioSequence() {
  const ctx = getAudioContext();
  if (!ctx) return;
  if (!state.soundEnabled || state.soundEffect === 'silent') {
    showToast('Sound is currently muted. Please enable sound first.');
    return;
  }

  showToast('Playing 3 - 2 - 1 - 0 Audio Test Sequence...');
  const now = ctx.currentTime;
  const effect = state.soundEffect;
  const vol = state.soundVolume;

  for (let i = 0; i < 3; i++) {
    const t = now + i * 0.65;
    if (effect === 'final_beep') {
      playDigitalBeepSound(ctx, ctx.destination, t, vol, 1400, 0.08);
    } else {
      switch (effect) {
        case 'tick': playClockTickSound(ctx, ctx.destination, t, vol); break;
        case 'beep': playDigitalBeepSound(ctx, ctx.destination, t, vol, 1200, 0.05); break;
        case 'click': playSoftClickSound(ctx, ctx.destination, t, vol); break;
        case 'pulse': playCinematicPulseSound(ctx, ctx.destination, t, vol); break;
        default: playClockTickSound(ctx, ctx.destination, t, vol);
      }
    }
  }

  // Final Chime at 00:00
  playTriumphantChime(ctx, ctx.destination, now + 3 * 0.65, vol);
}

// ---------------------------------------------------------------------------
// Canvas Drawing & Template Rendering Engine
// ---------------------------------------------------------------------------
function renderCanvasFrame(ctx, width, height, currentVideoTime, videoDuration, totalStartSec, opts) {
  // Clear canvas
  ctx.clearRect(0, 0, width, height);

  // 1. Draw Background
  ctx.fillStyle = opts.bgColor;
  ctx.fillRect(0, 0, width, height);

  // Calculate current countdown value
  const remainingSeconds = calculateRemainingTime(currentVideoTime, videoDuration, totalStartSec);
  const hasHours = totalStartSec >= 3600;
  const timeText = formatSecondsToDisplay(remainingSeconds, hasHours);

  // Base layout dimensions & scaling
  const minDim = Math.min(width, height);
  const baseScale = (minDim / 1000) * opts.fontScale;

  // Determine Center Y based on position preference
  let cx = width / 2;
  let cy = height / 2;
  if (opts.position === 'lower-third') {
    cy = height * 0.78;
  } else if (opts.position === 'top') {
    cy = height * 0.25;
  } else if (opts.position === 'bottom') {
    cy = height * 0.85;
  }

  // 2. Render Template
  ctx.save();
  switch (opts.template) {
    case 'gold':
      renderTemplateLuxuryGold(ctx, cx, cy, timeText, baseScale, opts);
      break;
    case 'blue':
      renderTemplateRoyalBlue(ctx, cx, cy, timeText, baseScale, opts);
      break;
    case 'pink':
      renderTemplateNeonPink(ctx, cx, cy, timeText, baseScale, opts);
      break;
    case 'red':
      renderTemplateCinematicRed(ctx, cx, cy, timeText, baseScale, opts);
      break;
    case 'chrome':
      renderTemplateSilverChrome(ctx, cx, cy, timeText, baseScale, opts);
      break;
    case 'purple':
      renderTemplatePurpleGlow(ctx, cx, cy, timeText, baseScale, opts);
      break;
    case 'green':
      renderTemplateEmeraldGreen(ctx, cx, cy, timeText, baseScale, opts);
      break;
    case 'led':
      renderTemplateDigitalLED(ctx, cx, cy, timeText, baseScale, opts);
      break;
    case 'minimal':
      renderTemplateMinimalClean(ctx, cx, cy, timeText, baseScale, opts, currentVideoTime, videoDuration);
      break;
    case 'glass':
      renderTemplateGlassEffect(ctx, cx, cy, timeText, baseScale, opts);
      break;
    default:
      renderTemplateLuxuryGold(ctx, cx, cy, timeText, baseScale, opts);
  }
  ctx.restore();
}

// 1. LUXURY GOLD TEMPLATE
function renderTemplateLuxuryGold(ctx, cx, cy, text, scale, opts) {
  const boxW = (text.length > 5 ? 780 : 580) * scale;
  const boxH = 260 * scale;
  const r = opts.cornerRadius * scale * 0.6;
  const borderThick = opts.frameThickness * scale * 0.8;

  if (!opts.isChromaPreset) {
    const aura = ctx.createRadialGradient(cx, cy, 50 * scale, cx, cy, 400 * scale);
    aura.addColorStop(0, 'rgba(218, 165, 32, 0.25)');
    aura.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = aura;
    ctx.beginPath();
    ctx.arc(cx, cy, 400 * scale, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.save();
  ctx.beginPath();
  roundRect(ctx, cx - boxW / 2, cy - boxH / 2, boxW, boxH, r);
  const innerGrad = ctx.createLinearGradient(cx, cy - boxH / 2, cx, cy + boxH / 2);
  innerGrad.addColorStop(0, '#1c1608');
  innerGrad.addColorStop(0.5, '#0d0a04');
  innerGrad.addColorStop(1, '#1a1406');
  ctx.fillStyle = innerGrad;
  ctx.fill();

  ctx.lineWidth = borderThick;
  const goldGrad = ctx.createLinearGradient(cx - boxW / 2, cy - boxH / 2, cx + boxW / 2, cy + boxH / 2);
  goldGrad.addColorStop(0.0, '#ffe57f');
  goldGrad.addColorStop(0.25, '#d4af37');
  goldGrad.addColorStop(0.5, '#aa771c');
  goldGrad.addColorStop(0.75, '#f7e089');
  goldGrad.addColorStop(1.0, '#996515');

  ctx.strokeStyle = opts.frameColor || goldGrad;
  ctx.shadowColor = opts.glowColor || 'rgba(245, 183, 0, 0.6)';
  ctx.shadowBlur = 24 * scale * opts.glowIntensity;
  ctx.stroke();
  ctx.restore();

  const studOffset = 18 * scale;
  const studRadius = 6 * scale;
  ctx.fillStyle = '#ffe57f';
  const corners = [
    [cx - boxW / 2 + studOffset, cy - boxH / 2 + studOffset],
    [cx + boxW / 2 - studOffset, cy - boxH / 2 + studOffset],
    [cx - boxW / 2 + studOffset, cy + boxH / 2 - studOffset],
    [cx + boxW / 2 - studOffset, cy + boxH / 2 - studOffset]
  ];
  for (const [sx, sy] of corners) {
    ctx.beginPath();
    ctx.arc(sx, sy, studRadius, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.save();
  ctx.font = `800 ${140 * scale}px ${opts.fontFamily}`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.shadowColor = '#000000';
  ctx.shadowBlur = 16 * scale;
  ctx.shadowOffsetY = 6 * scale;

  const textGrad = ctx.createLinearGradient(cx, cy - 60 * scale, cx, cy + 60 * scale);
  textGrad.addColorStop(0.0, '#ffffff');
  textGrad.addColorStop(0.3, '#ffea9f');
  textGrad.addColorStop(0.7, '#d4af37');
  textGrad.addColorStop(1.0, '#aa771c');

  ctx.fillStyle = opts.numColor || textGrad;
  ctx.fillText(text, cx, cy + 8 * scale);
  ctx.restore();
}

// 2. ROYAL BLUE TEMPLATE
function renderTemplateRoyalBlue(ctx, cx, cy, text, scale, opts) {
  const boxW = (text.length > 5 ? 760 : 560) * scale;
  const boxH = 250 * scale;
  const r = opts.cornerRadius * scale * 0.4;
  const borderThick = opts.frameThickness * scale * 0.8;

  ctx.save();
  ctx.beginPath();
  roundRect(ctx, cx - boxW / 2, cy - boxH / 2, boxW, boxH, r);
  ctx.fillStyle = '#050c18';
  ctx.fill();

  ctx.lineWidth = borderThick;
  ctx.strokeStyle = opts.frameColor || '#00d2ff';
  ctx.shadowColor = opts.glowColor || 'rgba(0, 210, 255, 0.9)';
  ctx.shadowBlur = 30 * scale * opts.glowIntensity;
  ctx.stroke();

  ctx.lineWidth = 4 * scale;
  ctx.strokeStyle = '#0077ff';
  const bLen = 30 * scale;
  const gap = 12 * scale;
  drawCornerBrackets(ctx, cx - boxW / 2 - gap, cy - boxH / 2 - gap, boxW + gap * 2, boxH + gap * 2, bLen);
  ctx.restore();

  ctx.save();
  ctx.font = `800 ${140 * scale}px ${opts.fontFamily}`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.shadowColor = opts.glowColor || '#00d2ff';
  ctx.shadowBlur = 25 * scale * opts.glowIntensity;
  ctx.fillStyle = opts.numColor || '#e0f7ff';
  ctx.fillText(text, cx, cy + 6 * scale);
  ctx.restore();
}

// 3. NEON PINK TEMPLATE
function renderTemplateNeonPink(ctx, cx, cy, text, scale, opts) {
  const boxW = (text.length > 5 ? 780 : 580) * scale;
  const boxH = 250 * scale;
  const r = opts.cornerRadius * scale * 0.5;
  const borderThick = opts.frameThickness * scale * 0.7;

  ctx.save();
  ctx.beginPath();
  roundRect(ctx, cx - boxW / 2, cy - boxH / 2, boxW, boxH, r);
  ctx.fillStyle = '#10030a';
  ctx.fill();

  ctx.lineWidth = borderThick;
  ctx.strokeStyle = opts.frameColor || '#ff007f';
  ctx.shadowColor = opts.glowColor || '#ff007f';
  ctx.shadowBlur = 35 * scale * opts.glowIntensity;
  ctx.stroke();

  ctx.lineWidth = Math.max(2, borderThick * 0.35);
  ctx.strokeStyle = '#ffffff';
  ctx.shadowBlur = 10 * scale;
  ctx.stroke();
  ctx.restore();

  ctx.save();
  ctx.font = `900 ${140 * scale}px ${opts.fontFamily}`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.shadowColor = opts.glowColor || '#ff007f';
  ctx.shadowBlur = 30 * scale * opts.glowIntensity;
  ctx.fillStyle = opts.numColor || '#ffffff';
  ctx.fillText(text, cx, cy + 6 * scale);

  ctx.lineWidth = 3 * scale;
  ctx.strokeStyle = '#ff007f';
  ctx.strokeText(text, cx, cy + 6 * scale);
  ctx.restore();
}

// 4. CINEMATIC RED TEMPLATE
function renderTemplateCinematicRed(ctx, cx, cy, text, scale, opts) {
  const boxW = (text.length > 5 ? 840 : 640) * scale;
  const boxH = 260 * scale;
  const borderThick = opts.frameThickness * scale;

  ctx.save();
  ctx.beginPath();
  ctx.rect(cx - boxW / 2, cy - boxH / 2, boxW, boxH);
  const redGrad = ctx.createLinearGradient(cx, cy - boxH / 2, cx, cy + boxH / 2);
  redGrad.addColorStop(0, '#220407');
  redGrad.addColorStop(0.5, '#110204');
  redGrad.addColorStop(1, '#250408');
  ctx.fillStyle = redGrad;
  ctx.fill();

  ctx.lineWidth = borderThick;
  ctx.strokeStyle = opts.frameColor || '#e50914';
  ctx.shadowColor = opts.glowColor || 'rgba(229, 9, 20, 0.7)';
  ctx.shadowBlur = 20 * scale * opts.glowIntensity;
  ctx.stroke();

  ctx.beginPath();
  const flareGrad = ctx.createLinearGradient(cx - boxW, cy, cx + boxW, cy);
  flareGrad.addColorStop(0, 'rgba(229, 9, 20, 0)');
  flareGrad.addColorStop(0.5, 'rgba(255, 60, 80, 0.8)');
  flareGrad.addColorStop(1, 'rgba(229, 9, 20, 0)');
  ctx.strokeStyle = flareGrad;
  ctx.lineWidth = 2 * scale;
  ctx.moveTo(cx - boxW / 2 - 80 * scale, cy);
  ctx.lineTo(cx + boxW / 2 + 80 * scale, cy);
  ctx.stroke();
  ctx.restore();

  ctx.save();
  ctx.font = `900 ${145 * scale}px ${opts.fontFamily}`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.shadowColor = '#000000';
  ctx.shadowBlur = 18 * scale;
  ctx.shadowOffsetY = 6 * scale;
  ctx.fillStyle = opts.numColor || '#f8fafc';
  ctx.fillText(text, cx, cy + 6 * scale);
  ctx.restore();
}

// 5. SILVER CHROME TEMPLATE
function renderTemplateSilverChrome(ctx, cx, cy, text, scale, opts) {
  const boxW = (text.length > 5 ? 780 : 580) * scale;
  const boxH = 250 * scale;
  const r = opts.cornerRadius * scale * 0.5;
  const borderThick = opts.frameThickness * scale * 0.9;

  ctx.save();
  ctx.beginPath();
  roundRect(ctx, cx - boxW / 2, cy - boxH / 2, boxW, boxH, r);
  ctx.fillStyle = '#171920';
  ctx.fill();

  const chromeGrad = ctx.createLinearGradient(cx - boxW / 2, cy - boxH / 2, cx + boxW / 2, cy + boxH / 2);
  chromeGrad.addColorStop(0.0, '#f8fafc');
  chromeGrad.addColorStop(0.2, '#94a3b8');
  chromeGrad.addColorStop(0.4, '#ffffff');
  chromeGrad.addColorStop(0.6, '#475569');
  chromeGrad.addColorStop(0.8, '#cbd5e1');
  chromeGrad.addColorStop(1.0, '#334155');

  ctx.lineWidth = borderThick;
  ctx.strokeStyle = opts.frameColor || chromeGrad;
  ctx.shadowColor = opts.glowColor || 'rgba(255, 255, 255, 0.4)';
  ctx.shadowBlur = 18 * scale * opts.glowIntensity;
  ctx.stroke();
  ctx.restore();

  ctx.save();
  ctx.font = `800 ${140 * scale}px ${opts.fontFamily}`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';

  const textChrome = ctx.createLinearGradient(cx, cy - 60 * scale, cx, cy + 60 * scale);
  textChrome.addColorStop(0.0, '#ffffff');
  textChrome.addColorStop(0.45, '#e2e8f0');
  textChrome.addColorStop(0.5, '#64748b');
  textChrome.addColorStop(0.55, '#f1f5f9');
  textChrome.addColorStop(1.0, '#cbd5e1');

  ctx.fillStyle = opts.numColor || textChrome;
  ctx.shadowColor = '#000';
  ctx.shadowBlur = 12 * scale;
  ctx.fillText(text, cx, cy + 8 * scale);
  ctx.restore();
}

// 6. PURPLE GLOW TEMPLATE
function renderTemplatePurpleGlow(ctx, cx, cy, text, scale, opts) {
  const boxW = (text.length > 5 ? 760 : 560) * scale;
  const boxH = 250 * scale;
  const r = opts.cornerRadius * scale * 0.7;
  const borderThick = opts.frameThickness * scale * 0.8;

  ctx.save();
  ctx.beginPath();
  roundRect(ctx, cx - boxW / 2, cy - boxH / 2, boxW, boxH, r);
  ctx.fillStyle = '#0d0718';
  ctx.fill();

  ctx.lineWidth = borderThick;
  ctx.strokeStyle = opts.frameColor || '#c084fc';
  ctx.shadowColor = opts.glowColor || '#9333ea';
  ctx.shadowBlur = 32 * scale * opts.glowIntensity;
  ctx.stroke();
  ctx.restore();

  ctx.save();
  ctx.font = `800 ${140 * scale}px ${opts.fontFamily}`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.shadowColor = opts.glowColor || '#c084fc';
  ctx.shadowBlur = 24 * scale * opts.glowIntensity;
  ctx.fillStyle = opts.numColor || '#f5d0fe';
  ctx.fillText(text, cx, cy + 6 * scale);
  ctx.restore();
}

// 7. EMERALD GREEN TEMPLATE
function renderTemplateEmeraldGreen(ctx, cx, cy, text, scale, opts) {
  const boxW = (text.length > 5 ? 780 : 580) * scale;
  const boxH = 250 * scale;
  const chamfer = 24 * scale;
  const borderThick = opts.frameThickness * scale * 0.8;

  ctx.save();
  ctx.beginPath();
  drawChamferBox(ctx, cx - boxW / 2, cy - boxH / 2, boxW, boxH, chamfer);
  ctx.fillStyle = '#03140c';
  ctx.fill();

  ctx.lineWidth = borderThick;
  ctx.strokeStyle = opts.frameColor || '#00ff88';
  ctx.shadowColor = opts.glowColor || '#059669';
  ctx.shadowBlur = 26 * scale * opts.glowIntensity;
  ctx.stroke();

  ctx.lineWidth = 3 * scale;
  ctx.strokeStyle = '#34d399';
  const cLen = 20 * scale;
  ctx.moveTo(cx - boxW / 2 + chamfer, cy - boxH / 2 + 6 * scale);
  ctx.lineTo(cx - boxW / 2 + chamfer + cLen, cy - boxH / 2 + 6 * scale);
  ctx.moveTo(cx + boxW / 2 - chamfer, cy - boxH / 2 + 6 * scale);
  ctx.lineTo(cx + boxW / 2 - chamfer - cLen, cy - boxH / 2 + 6 * scale);
  ctx.stroke();
  ctx.restore();

  ctx.save();
  ctx.font = `800 ${140 * scale}px ${opts.fontFamily}`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.shadowColor = opts.glowColor || '#00ff88';
  ctx.shadowBlur = 22 * scale * opts.glowIntensity;
  ctx.fillStyle = opts.numColor || '#a7f3d0';
  ctx.fillText(text, cx, cy + 6 * scale);
  ctx.restore();
}

// 8. DIGITAL LED (AUTHENTIC 7-SEGMENT VECTOR DISPLAY)
function renderTemplateDigitalLED(ctx, cx, cy, text, scale, opts) {
  const charCount = text.length;
  const digitW = 75 * scale;
  const digitH = 145 * scale;
  const segThickness = 12 * scale;
  const spacing = 20 * scale;
  const colonW = 30 * scale;

  let totalW = 0;
  for (let i = 0; i < charCount; i++) {
    totalW += text[i] === ':' ? colonW : digitW;
    if (i < charCount - 1) totalW += spacing;
  }

  const boxPadX = 50 * scale;
  const boxPadY = 40 * scale;
  const boxW = totalW + boxPadX * 2;
  const boxH = digitH + boxPadY * 2;
  const r = 16 * scale;

  ctx.save();
  ctx.beginPath();
  roundRect(ctx, cx - boxW / 2, cy - boxH / 2, boxW, boxH, r);
  ctx.fillStyle = '#080a0e';
  ctx.fill();

  ctx.lineWidth = opts.frameThickness * scale * 0.7;
  ctx.strokeStyle = opts.frameColor || '#1e2430';
  ctx.stroke();

  const glassGrad = ctx.createLinearGradient(cx, cy - boxH / 2, cx, cy);
  glassGrad.addColorStop(0, 'rgba(255, 255, 255, 0.08)');
  glassGrad.addColorStop(1, 'rgba(255, 255, 255, 0)');
  ctx.fillStyle = glassGrad;
  ctx.beginPath();
  roundRect(ctx, cx - boxW / 2 + 4, cy - boxH / 2 + 4, boxW - 8, boxH / 2, r);
  ctx.fill();
  ctx.restore();

  const activeColor = opts.numColor || '#ff2222';
  const inactiveColor = 'rgba(255, 34, 34, 0.07)';
  const glowColor = opts.glowColor || activeColor;

  let startX = cx - totalW / 2;
  const startY = cy - digitH / 2;

  for (let i = 0; i < charCount; i++) {
    const ch = text[i];
    if (ch === ':') {
      drawLEDColon(ctx, startX + colonW / 2, cy, 8 * scale, 26 * scale, activeColor, glowColor, scale, opts.glowIntensity);
      startX += colonW + spacing;
    } else {
      const segs = LED_SEGMENTS[ch] || LED_SEGMENTS['8'];
      draw7SegmentDigit(ctx, startX, startY, digitW, digitH, segThickness, segs, activeColor, inactiveColor, glowColor, scale, opts.glowIntensity);
      startX += digitW + spacing;
    }
  }
}

function draw7SegmentDigit(ctx, x, y, w, h, t, segs, activeColor, inactiveColor, glowColor, scale, glowInt) {
  const halfH = h / 2;
  const segmentPaths = [
    () => {
      ctx.beginPath();
      ctx.moveTo(x + t, y);
      ctx.lineTo(x + w - t, y);
      ctx.lineTo(x + w - t * 1.5, y + t);
      ctx.lineTo(x + t * 1.5, y + t);
      ctx.closePath();
    },
    () => {
      ctx.beginPath();
      ctx.moveTo(x + w, y + t);
      ctx.lineTo(x + w, y + halfH - t / 2);
      ctx.lineTo(x + w - t, y + halfH - t);
      ctx.lineTo(x + w - t, y + t * 1.5);
      ctx.closePath();
    },
    () => {
      ctx.beginPath();
      ctx.moveTo(x + w, y + halfH + t / 2);
      ctx.lineTo(x + w, y + h - t);
      ctx.lineTo(x + w - t, y + h - t * 1.5);
      ctx.lineTo(x + w - t, y + halfH + t);
      ctx.closePath();
    },
    () => {
      ctx.beginPath();
      ctx.moveTo(x + t, y + h);
      ctx.lineTo(x + w - t, y + h);
      ctx.lineTo(x + w - t * 1.5, y + h - t);
      ctx.lineTo(x + t * 1.5, y + h - t);
      ctx.closePath();
    },
    () => {
      ctx.beginPath();
      ctx.moveTo(x, y + halfH + t / 2);
      ctx.lineTo(x, y + h - t);
      ctx.lineTo(x + t, y + h - t * 1.5);
      ctx.lineTo(x + t, y + halfH + t);
      ctx.closePath();
    },
    () => {
      ctx.beginPath();
      ctx.moveTo(x, y + t);
      ctx.lineTo(x, y + halfH - t / 2);
      ctx.lineTo(x + t, y + halfH - t);
      ctx.lineTo(x + t, y + t * 1.5);
      ctx.closePath();
    },
    () => {
      ctx.beginPath();
      ctx.moveTo(x + t * 1.2, y + halfH);
      ctx.lineTo(x + t * 1.8, y + halfH - t / 2);
      ctx.lineTo(x + w - t * 1.8, y + halfH - t / 2);
      ctx.lineTo(x + w - t * 1.2, y + halfH);
      ctx.lineTo(x + w - t * 1.8, y + halfH + t / 2);
      ctx.lineTo(x + t * 1.8, y + halfH + t / 2);
      ctx.closePath();
    }
  ];

  for (let i = 0; i < 7; i++) {
    const isActive = segs[i] === 1;
    segmentPaths[i]();

    ctx.save();
    if (isActive) {
      ctx.fillStyle = activeColor;
      ctx.shadowColor = glowColor;
      ctx.shadowBlur = 18 * scale * glowInt;
      ctx.fill();
    } else {
      ctx.fillStyle = inactiveColor;
      ctx.fill();
    }
    ctx.restore();
  }
}

function drawLEDColon(ctx, x, cy, dotRadius, spacing, activeColor, glowColor, scale, glowInt) {
  ctx.save();
  ctx.fillStyle = activeColor;
  ctx.shadowColor = glowColor;
  ctx.shadowBlur = 16 * scale * glowInt;

  ctx.beginPath();
  ctx.arc(x, cy - spacing, dotRadius, 0, Math.PI * 2);
  ctx.fill();

  ctx.beginPath();
  ctx.arc(x, cy + spacing, dotRadius, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

// 9. MINIMAL CLEAN TEMPLATE
function renderTemplateMinimalClean(ctx, cx, cy, text, scale, opts, currentSec, durationSec) {
  const boxW = (text.length > 5 ? 740 : 540) * scale;
  const boxH = 240 * scale;
  const r = opts.cornerRadius * scale * 0.3;

  ctx.save();
  ctx.beginPath();
  roundRect(ctx, cx - boxW / 2, cy - boxH / 2, boxW, boxH, r);
  ctx.fillStyle = 'rgba(255, 255, 255, 0.03)';
  ctx.fill();

  ctx.lineWidth = Math.max(1.5, opts.frameThickness * scale * 0.4);
  ctx.strokeStyle = opts.frameColor || 'rgba(255, 255, 255, 0.3)';
  ctx.stroke();

  const progress = durationSec > 0 ? Math.min(1, currentSec / durationSec) : 0;
  const lineY = cy + boxH / 2 - 4 * scale;
  ctx.beginPath();
  ctx.moveTo(cx - boxW / 2 + 10 * scale, lineY);
  ctx.lineTo(cx - boxW / 2 + 10 * scale + (boxW - 20 * scale) * (1 - progress), lineY);
  ctx.lineWidth = 3 * scale;
  ctx.strokeStyle = opts.numColor || '#ffffff';
  ctx.stroke();
  ctx.restore();

  ctx.save();
  ctx.font = `600 ${140 * scale}px ${opts.fontFamily}`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = opts.numColor || '#f8fafc';
  ctx.fillText(text, cx, cy - 2 * scale);
  ctx.restore();
}

// 10. GLASS EFFECT TEMPLATE
function renderTemplateGlassEffect(ctx, cx, cy, text, scale, opts) {
  const boxW = (text.length > 5 ? 780 : 580) * scale;
  const boxH = 250 * scale;
  const r = opts.cornerRadius * scale * 0.8;

  ctx.save();
  ctx.beginPath();
  roundRect(ctx, cx - boxW / 2, cy - boxH / 2, boxW, boxH, r);
  ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
  ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
  ctx.shadowBlur = 30 * scale;
  ctx.shadowOffsetY = 10 * scale;
  ctx.fill();

  const rimGrad = ctx.createLinearGradient(cx - boxW / 2, cy - boxH / 2, cx + boxW / 2, cy + boxH / 2);
  rimGrad.addColorStop(0, 'rgba(255, 255, 255, 0.7)');
  rimGrad.addColorStop(0.5, 'rgba(255, 255, 255, 0.15)');
  rimGrad.addColorStop(1, 'rgba(255, 255, 255, 0.4)');

  ctx.lineWidth = opts.frameThickness * scale * 0.6;
  ctx.strokeStyle = opts.frameColor || rimGrad;
  ctx.shadowColor = opts.glowColor || 'rgba(255, 255, 255, 0.2)';
  ctx.shadowBlur = 15 * scale * opts.glowIntensity;
  ctx.stroke();
  ctx.restore();

  ctx.save();
  ctx.font = `800 ${140 * scale}px ${opts.fontFamily}`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = opts.numColor || 'rgba(255, 255, 255, 0.95)';
  ctx.shadowColor = 'rgba(0, 0, 0, 0.4)';
  ctx.shadowBlur = 12 * scale;
  ctx.fillText(text, cx, cy + 6 * scale);
  ctx.restore();
}

function roundRect(ctx, x, y, width, height, radius) {
  const r = Math.min(radius, width / 2, height / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + width - r, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + r);
  ctx.lineTo(x + width, y + height - r);
  ctx.quadraticCurveTo(x + width, y + height, x + width - r, y + height);
  ctx.lineTo(x + r, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function drawChamferBox(ctx, x, y, w, h, c) {
  ctx.beginPath();
  ctx.moveTo(x + c, y);
  ctx.lineTo(x + w - c, y);
  ctx.lineTo(x + w, y + c);
  ctx.lineTo(x + w, y + h - c);
  ctx.lineTo(x + w - c, y + h);
  ctx.lineTo(x + c, y + h);
  ctx.lineTo(x, y + h - c);
  ctx.lineTo(x, y + c);
  ctx.closePath();
}

function drawCornerBrackets(ctx, x, y, w, h, len) {
  ctx.beginPath();
  ctx.moveTo(x, y + len); ctx.lineTo(x, y); ctx.lineTo(x + len, y);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(x + w - len, y); ctx.lineTo(x + w, y); ctx.lineTo(x + w, y + len);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(x, y + h - len); ctx.lineTo(x, y + h); ctx.lineTo(x + len, y + h);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(x + w - len, y + h); ctx.lineTo(x + w, y + h); ctx.lineTo(x + w, y + h - len);
  ctx.stroke();
}

// ---------------------------------------------------------------------------
// Best Supported Video MIME Type Resolver
// ---------------------------------------------------------------------------
function getBestVideoMimeType(includeAudio = true) {
  if (typeof MediaRecorder === 'undefined' || typeof MediaRecorder.isTypeSupported !== 'function') {
    return { mimeType: '', ext: 'webm', name: 'WebM Video' };
  }

  if (typeof MediaRecorder === 'undefined') {
    return { mimeType: '', ext: 'webm', name: 'Browser unsupported' };
  }

  const audioCandidates = [
    { mimeType: 'video/mp4;codecs=avc1.42E01E,mp4a.40.2', ext: 'mp4', name: 'MP4 (H.264 / AAC)' },
    { mimeType: 'video/mp4;codecs=avc1,mp4a.40.2', ext: 'mp4', name: 'MP4 (H.264 / AAC)' },
    { mimeType: 'video/mp4;codecs=h264,aac', ext: 'mp4', name: 'MP4 (H.264 / AAC)' },
    { mimeType: 'video/mp4', ext: 'mp4', name: 'MP4 Video' },
    { mimeType: 'video/webm;codecs=vp9,opus', ext: 'webm', name: 'WebM (VP9 / Opus)' },
    { mimeType: 'video/webm;codecs=vp8,opus', ext: 'webm', name: 'WebM (VP8 / Opus)' },
    { mimeType: 'video/webm;codecs=h264,opus', ext: 'webm', name: 'WebM (H.264 / Opus)' },
    { mimeType: 'video/webm', ext: 'webm', name: 'WebM Video' }
  ];

  const silentCandidates = [
    { mimeType: 'video/mp4;codecs=avc1.42E01E', ext: 'mp4', name: 'MP4 (H.264)' },
    { mimeType: 'video/mp4;codecs=avc1', ext: 'mp4', name: 'MP4 (H.264)' },
    { mimeType: 'video/mp4;codecs=h264', ext: 'mp4', name: 'MP4 (H.264)' },
    { mimeType: 'video/mp4', ext: 'mp4', name: 'MP4 Video' },
    { mimeType: 'video/webm;codecs=vp9', ext: 'webm', name: 'WebM (VP9)' },
    { mimeType: 'video/webm;codecs=vp8', ext: 'webm', name: 'WebM (VP8)' },
    { mimeType: 'video/webm;codecs=h264', ext: 'webm', name: 'WebM (H.264)' },
    { mimeType: 'video/webm', ext: 'webm', name: 'WebM Video' }
  ];

  const list = includeAudio ? audioCandidates : silentCandidates;
  for (const c of list) {
    try {
      if (MediaRecorder.isTypeSupported(c.mimeType)) {
        return c;
      }
    } catch (e) {}
  }

  if (MediaRecorder.isTypeSupported('video/mp4')) {
    return { mimeType: 'video/mp4', ext: 'mp4', name: 'MP4 Video' };
  }
  if (MediaRecorder.isTypeSupported('video/webm')) {
    return { mimeType: 'video/webm', ext: 'webm', name: 'WebM Video' };
  }

  return { mimeType: '', ext: 'webm', name: 'WebM Video' };
}

// ---------------------------------------------------------------------------
// Video Recording & Generation Pipeline (Real Frame Recording & Audio Mixing)
// ---------------------------------------------------------------------------
async function generateCountdownVideo() {
  if (state.isGenerating) return;

  hideErrorNotice();

  if (typeof MediaRecorder === 'undefined') {
    showErrorNotice('MediaRecorder is not supported by your browser. Please use Google Chrome, Microsoft Edge, or Mozilla Firefox.');
    return;
  }

  const timeInput = document.getElementById('timeInput');
  const enteredTime = timeInput ? timeInput.value.trim() : state.timeString;
  const parsedStartTime = parseTimeString(enteredTime);
  if (!Number.isFinite(parsedStartTime) || parsedStartTime <= 0) {
    showErrorNotice('Enter a valid countdown time greater than 0. Use MM:SS or HH:MM:SS (for example, 03:00 or 01:00:00).');
    if (timeInput) {
      timeInput.setAttribute('aria-invalid', 'true');
      timeInput.focus();
    }
    return;
  }
  state.startSeconds = parsedStartTime;
  state.timeString = enteredTime;
  if (timeInput) timeInput.setAttribute('aria-invalid', 'false');

  const totalStartSec = state.startSeconds;
  let videoDurationSec = totalStartSec;
  if (state.durationMode === 'compressed') {
    const durationInput = document.getElementById('outputDurationInput');
    const requestedDuration = durationInput ? Number(durationInput.value) : state.outputDuration;
    if (!Number.isInteger(requestedDuration) || requestedDuration < 1 || requestedDuration > 600) {
      showErrorNotice('Choose an output duration between 1 and 600 seconds.');
      if (durationInput) {
        durationInput.setAttribute('aria-invalid', 'true');
        durationInput.focus();
      }
      return;
    }
    state.outputDuration = requestedDuration;
    if (durationInput) durationInput.setAttribute('aria-invalid', 'false');
    videoDurationSec = requestedDuration;
  }

  if (totalStartSec <= 0 || videoDurationSec <= 0) {
    showErrorNotice('Please enter a valid starting countdown time greater than 0.');
    return;
  }

  let hasAudio = state.soundEnabled && state.soundEffect !== 'silent';
  const mimeInfo = getBestVideoMimeType(hasAudio);

  // Set UI to generating state
  state.isGenerating = true;
  state.isCancelled = false;
  state.currentMimeType = mimeInfo.mimeType;
  state.currentFileExt = mimeInfo.ext;

  const btnGenerate = document.getElementById('btnGenerateVideo');
  const progressBox = document.getElementById('progressContainer');
  const progressFill = document.getElementById('progressFill');
  const progressPct = document.getElementById('progressPct');
  const progressStats = document.getElementById('progressStats');
  const videoResultCard = document.getElementById('videoResultCard');

  btnGenerate.disabled = true;
  progressBox.classList.add('active');
  videoResultCard.classList.remove('active');

  // Dedicated off-screen high-res render canvas matching exact resolution
  let renderCanvas = document.getElementById('renderCanvasOffscreen');
  if (!renderCanvas) {
    renderCanvas = document.createElement('canvas');
    renderCanvas.id = 'renderCanvasOffscreen';
    renderCanvas.style.cssText = 'position:fixed;left:-99999px;top:0;pointer-events:none;opacity:0;z-index:-1;';
    document.body.appendChild(renderCanvas);
  }
  renderCanvas.width = state.resolution.width;
  renderCanvas.height = state.resolution.height;
  const rCtx = renderCanvas.getContext('2d', { alpha: false });

  if (!rCtx) {
    state.isGenerating = false;
    btnGenerate.disabled = false;
    progressBox.classList.remove('active');
    showErrorNotice('This browser could not create a 2D canvas. Please reload the page or try another browser.');
    return;
  }
  if (typeof renderCanvas.captureStream !== 'function' || typeof MediaStream === 'undefined') {
    state.isGenerating = false;
    btnGenerate.disabled = false;
    progressBox.classList.remove('active');
    showErrorNotice('This browser cannot record a canvas stream. Please use an up-to-date Chrome, Edge, or Firefox browser.');
    return;
  }


  // Web Audio Recording Destination
  let liveAudioCtx = null;
  let recordAudioDest = null;
  let audioTrack = null;
  let silenceSource = null;

  if (hasAudio) {
    try {
      liveAudioCtx = getAudioContext();
      if (liveAudioCtx.state === 'suspended') {
        await liveAudioCtx.resume();
      }
      recordAudioDest = liveAudioCtx.createMediaStreamDestination();
      const tracks = recordAudioDest.stream.getAudioTracks();
      if (tracks && tracks.length > 0) {
        audioTrack = tracks[0];
      }

      // Keep audio stream continuously active so MediaRecorder records synchronized audio track from frame 0
      const silenceOsc = liveAudioCtx.createOscillator();
      const silenceGain = liveAudioCtx.createGain();
      silenceGain.gain.setValueAtTime(0.00001, liveAudioCtx.currentTime);
      silenceOsc.connect(silenceGain);
      silenceGain.connect(recordAudioDest);
      silenceOsc.start();
      silenceSource = silenceOsc;
    } catch (err) {
      console.warn('Audio destination creation failed, proceeding with video only:', err);
      hasAudio = false;
      if (silenceSource) {
        try { silenceSource.stop(); } catch (stopError) {}
        silenceSource = null;
      }
      showToast('Audio is not available in this browser session. Continuing with silent video.');
    }
  }

  const fps = state.fps;
  let canvasStream;
  let combinedStream;
  try {
    canvasStream = renderCanvas.captureStream(fps);
    combinedStream = new MediaStream();
    canvasStream.getVideoTracks().forEach(track => combinedStream.addTrack(track));
    if (audioTrack && hasAudio) combinedStream.addTrack(audioTrack);
  } catch (err) {
    state.isGenerating = false;
    btnGenerate.disabled = false;
    progressBox.classList.remove('active');
    if (silenceSource) {
      try { silenceSource.stop(); } catch (stopError) {}
    }
    showErrorNotice(`Could not start the recording stream: ${err.message || 'unsupported browser feature'}. Use an up-to-date browser over HTTPS or localhost.`);
    return;
  }

  const recordedChunks = [];
  let mediaRecorder = null;
  const bitsPerSecond = state.resolution.width >= 1920 ? 12000000 : 7000000;

  try {
    if (mimeInfo.mimeType) {
      mediaRecorder = new MediaRecorder(combinedStream, {
        mimeType: mimeInfo.mimeType,
        videoBitsPerSecond: bitsPerSecond
      });
    } else {
      mediaRecorder = new MediaRecorder(combinedStream);
    }
  } catch (err1) {
    try {
      mediaRecorder = new MediaRecorder(combinedStream);
    } catch (err2) {
      state.isGenerating = false;
      btnGenerate.disabled = false;
      progressBox.classList.remove('active');
      showErrorNotice(`Unable to start video recorder: ${err2.message || 'Browser permission error'}.`);
      return;
    }
  }

  // Update actual MIME and file extension
  if (mediaRecorder.mimeType) {
    state.currentMimeType = mediaRecorder.mimeType;
    state.currentFileExt = mediaRecorder.mimeType.toLowerCase().includes('mp4') ? 'mp4' : 'webm';
  }

  mediaRecorder.ondataavailable = (e) => {
    if (e.data && e.data.size > 0) {
      recordedChunks.push(e.data);
    }
  };

  const totalFrames = Math.max(1, Math.round(videoDurationSec * fps));
  let currentFrame = 0;
  let lastAudioSecond = -1;
  let lastTickTime = 0;

  // Draw initial frame (exact start time)
  renderCanvasFrame(rCtx, renderCanvas.width, renderCanvas.height, 0, videoDurationSec, totalStartSec, state);

  try {
    mediaRecorder.start(100);
  } catch (err) {
    state.isGenerating = false;
    btnGenerate.disabled = false;
    progressBox.classList.remove('active');
    showErrorNotice(`Failed to start MediaRecorder: ${err.message}`);
    return;
  }

  const startTimeEpoch = performance.now();

  function triggerRecordedSound(isEnding = false) {
    if (!hasAudio) return;
    try {
      if (isEnding) {
        playSynthesizedSound(state.soundEffect, { destination: recordAudioDest, isFinalChime: true, volume: state.soundVolume });
        playSynthesizedSound(state.soundEffect, { destination: liveAudioCtx.destination, isFinalChime: true, volume: state.soundVolume * 0.7 });
      } else {
        playSynthesizedSound(state.soundEffect, { destination: recordAudioDest, volume: state.soundVolume });
        playSynthesizedSound(state.soundEffect, { destination: liveAudioCtx.destination, volume: state.soundVolume * 0.7 });
      }
    } catch (e) {}
  }

    let isFinishedRecording = false;

    function finalizeVideoRecording() {
      if (isFinishedRecording) return;
      isFinishedRecording = true;
      if (watchdogTimer) clearInterval(watchdogTimer);

      // Draw exact final frame (00:00)
      renderCanvasFrame(rCtx, renderCanvas.width, renderCanvas.height, videoDurationSec, videoDurationSec, totalStartSec, state);

      // Play final triumphant chime
      triggerRecordedSound(true);

      progressFill.style.width = '100%';
      progressPct.textContent = '100%';
      progressStats.innerHTML = `
        <span>Frame: ${totalFrames} / ${totalFrames}</span>
        <span>Elapsed: ${videoDurationSec.toFixed(1)}s</span>
        <span>Status: Finalizing Video...</span>
      `;

      // Allow final sound reverberation before closing recorder stream
      setTimeout(() => {
        try {
          if (mediaRecorder && mediaRecorder.state !== 'inactive') {
            mediaRecorder.stop();
          }
        } catch (err) {}
      }, 450);
    }

    const watchdogTimer = setInterval(() => {
      if (state.isCancelled) {
        clearInterval(watchdogTimer);
        return;
      }
      const now = performance.now();
      const elapsed = (now - startTimeEpoch) / 1000;
      if (elapsed >= videoDurationSec) {
        finalizeVideoRecording();
      }
    }, 100);

    const renderFrameStep = () => {
      if (state.isCancelled) {
        if (watchdogTimer) clearInterval(watchdogTimer);
        try { mediaRecorder.stop(); } catch (err) {}
        finishCancelled();
        return;
      }

      const now = performance.now();
      const elapsedRealSec = (now - startTimeEpoch) / 1000;

      if (elapsedRealSec >= videoDurationSec) {
        finalizeVideoRecording();
        return;
      }

      // Mathematical countdown rendering based on precise timestamp
      renderCanvasFrame(rCtx, renderCanvas.width, renderCanvas.height, elapsedRealSec, videoDurationSec, totalStartSec, state);

      // Audio synchronization
      if (hasAudio) {
        if (state.durationMode === 'realtime') {
          const curRemaining = calculateRemainingTime(elapsedRealSec, videoDurationSec, totalStartSec);
          if (curRemaining !== lastAudioSecond) {
            lastAudioSecond = curRemaining;
            if (curRemaining > 0) {
              triggerRecordedSound(false);
            }
          }
        } else {
          // Compressed mode: rhythmic pacing without distortion
          const paceInterval = videoDurationSec >= 20 ? 1.0 : (videoDurationSec >= 8 ? 0.5 : 0.25);
          if (elapsedRealSec - lastTickTime >= paceInterval) {
            lastTickTime = elapsedRealSec;
            triggerRecordedSound(false);
          }
        }
      }

      const curFrame = Math.min(totalFrames, Math.round(elapsedRealSec * fps));
      const pct = Math.min(99, Math.round((elapsedRealSec / videoDurationSec) * 100));
      progressFill.style.width = `${pct}%`;
      progressPct.textContent = `${pct}%`;

      const estTotalRealSec = pct > 0 ? (elapsedRealSec / pct) * 100 : videoDurationSec;
      const estRemaining = Math.max(0, Math.round(estTotalRealSec - elapsedRealSec));

      progressStats.innerHTML = `
        <span>Frame: ${curFrame} / ${totalFrames}</span>
        <span>Elapsed: ${elapsedRealSec.toFixed(1)}s</span>
        <span>Remaining: ~${estRemaining}s</span>
      `;

      if (!isFinishedRecording) {
        requestAnimationFrame(renderFrameStep);
      }
    };

    requestAnimationFrame(renderFrameStep);

  mediaRecorder.onstop = () => {
    if (silenceSource) {
      try { silenceSource.stop(); } catch (e) {}
    }

    if (state.isCancelled) return;

    if (recordedChunks.length === 0) {
      state.isGenerating = false;
      btnGenerate.disabled = false;
      progressBox.classList.remove('active');
      showErrorNotice('Video recording produced an empty stream. Please try selecting a different resolution or browser.');
      return;
    }

    const videoBlob = new Blob(recordedChunks, { type: state.currentMimeType });

    if (videoBlob.size === 0) {
      state.isGenerating = false;
      btnGenerate.disabled = false;
      progressBox.classList.remove('active');
      showErrorNotice('Generated video file is 0 bytes. Please try another resolution or browser.');
      return;
    }

    // Revoke previous blob URL safely before assigning the new one
    if (state.currentVideoUrl) {
      URL.revokeObjectURL(state.currentVideoUrl);
    }

    state.currentVideoBlob = videoBlob;
    state.currentVideoUrl = URL.createObjectURL(videoBlob);
    state.videoFileSize = formatBytes(videoBlob.size);

    finishSuccess();
  };

  function finishCancelled() {
    if (silenceSource) {
      try { silenceSource.stop(); } catch (e) {}
    }
    state.isGenerating = false;
    btnGenerate.disabled = false;
    progressBox.classList.remove('active');
    showToast('Video generation cancelled.');
  }

  function finishSuccess() {
    state.isGenerating = false;
    btnGenerate.disabled = false;
    progressBox.classList.remove('active');

    videoResultCard.classList.add('active');
    const player = document.getElementById('completedVideoPlayer');
    player.src = state.currentVideoUrl;

    const audioMeta = (hasAudio ? `Audio: ${state.soundEffect.toUpperCase()}` : 'Silent');
    document.getElementById('resultFileMeta').textContent =
      `${state.currentFileExt.toUpperCase()} • ${state.videoFileSize} • ${state.resolution.name} • ${audioMeta}`;
    document.getElementById('filenameExt').textContent = `.${state.currentFileExt}`;

    const safeTpl = state.template.toUpperCase();
    const safeTime = state.timeString.replace(/:/g, '-');
    const defaultBase = `Countdown_${safeTime}_${safeTpl}`;
    document.getElementById('filenameInput').value = defaultBase;

    // Direct native link configuration on anchor
    const btnDownload = document.getElementById('btnDownloadVideo');
    if (btnDownload) {
      btnDownload.href = state.currentVideoUrl;
      btnDownload.download = `${defaultBase}.${state.currentFileExt}`;
    }

    const playerBox = document.getElementById('videoPlayerBox');
    playerBox.className = 'video-player-box';
    if (state.resolution.width === 1080 && state.resolution.height === 1920) {
      playerBox.classList.add('ratio-vertical');
    } else if (state.resolution.width === state.resolution.height) {
      playerBox.classList.add('ratio-square');
    }

    try {
      player.load();
    } catch (e) {}

    setTimeout(() => {
      videoResultCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 150);

    showToast('🎉 Video successfully generated! Click DOWNLOAD VIDEO to save to your device.');

    if (window.confetti) {
      try {
        window.confetti({ particleCount: 65, spread: 70, origin: { y: 0.6 } });
      } catch (e) {}
    }
  }
}

/**
 * Computes a sanitized, valid filename with the correct extension.
 */
function getCleanFilename() {
  const filenameInput = document.getElementById('filenameInput');
  let baseName = filenameInput ? filenameInput.value.trim() : '';
  if (!baseName) {
    const safeTpl = state.template.toUpperCase();
    const safeTime = state.timeString.replace(/:/g, '-');
    baseName = `Countdown_${safeTime}_${safeTpl}`;
  }

  const safeName = baseName.replace(/[/\\?%*:|"<>]/g, '_');
  const cleanBase = safeName.replace(new RegExp(`\\.${state.currentFileExt}$`, 'i'), '');
  return `${cleanBase}.${state.currentFileExt}`;
}

/**
 * Downloads the SAME generated video repeatedly without re-rendering.
 * Retains the Blob and object URL in memory across multiple clicks.
 */
function downloadGeneratedVideo(e) {
  if (!state.currentVideoBlob || !state.currentVideoUrl) {
    if (e && e.preventDefault) e.preventDefault();
    showErrorNotice('No video has been generated yet. Click "GENERATE COUNTDOWN VIDEO" to create your video first.');
    return;
  }

  if (state.currentVideoBlob.size === 0) {
    if (e && e.preventDefault) e.preventDefault();
    showErrorNotice('The recorded video file is empty. Please regenerate.');
    return;
  }

  const fullFileName = getCleanFilename();
  const btnDownload = document.getElementById('btnDownloadVideo');
  if (btnDownload) {
    btnDownload.href = state.currentVideoUrl;
    btnDownload.download = fullFileName;
  }

  // If triggered by a programmatic call or non-native event:
  if (!e || e.currentTarget !== btnDownload) {
    const a = document.createElement('a');
    a.style.cssText = 'position:fixed;left:-9999px;top:-9999px;opacity:0;pointer-events:none;';
    a.href = state.currentVideoUrl;
    a.download = fullFileName;
    a.setAttribute('download', fullFileName);
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { if (a.parentNode) a.parentNode.removeChild(a); }, 2000);
  }

  showToast(`⬇️ Download started: ${fullFileName} (${state.videoFileSize})`);
}

function showErrorNotice(msg) {
  const alertBox = document.getElementById('errorAlertBox');
  const msgEl = document.getElementById('errorAlertMsg');
  if (alertBox && msgEl) {
    msgEl.textContent = msg;
    alertBox.style.display = 'block';
    alertBox.scrollIntoView({ behavior: 'smooth', block: 'center' });
  } else {
    alert(msg);
  }
}

function hideErrorNotice() {
  const alertBox = document.getElementById('errorAlertBox');
  if (alertBox) {
    alertBox.style.display = 'none';
  }
}

// ---------------------------------------------------------------------------
// Live Preview Loop
// ---------------------------------------------------------------------------
function startPreviewLoop() {
  const canvas = document.getElementById('previewCanvas');
  const ctx = canvas.getContext('2d');
  const scrubSlider = document.getElementById('scrubSlider');
  const previewTimeLabel = document.getElementById('previewTimeLabel');

  function tick(timestamp) {
    if (!state.lastPreviewTimestamp) state.lastPreviewTimestamp = timestamp;
    const delta = (timestamp - state.lastPreviewTimestamp) / 1000;
    state.lastPreviewTimestamp = timestamp;

    const totalStartSec = state.startSeconds;
    const videoDuration = state.durationMode === 'compressed' ? state.outputDuration : totalStartSec;

    // Advance time if playing
    if (state.previewPlaying && !state.isGenerating) {
      state.previewTime += delta;
      if (state.previewTime > videoDuration) {
        state.previewTime = 0; // loop preview
      }
    }

    // Update scrubber
    if (videoDuration > 0) {
      const pct = (state.previewTime / videoDuration) * 100;
      scrubSlider.value = pct;
    }

    const curRemaining = calculateRemainingTime(state.previewTime, videoDuration, totalStartSec);
    previewTimeLabel.textContent = `${formatSecondsToDisplay(curRemaining)} / ${formatSecondsToDisplay(totalStartSec)}`;

    // Match canvas display resolution
    if (canvas.width !== state.resolution.width || canvas.height !== state.resolution.height) {
      canvas.width = state.resolution.width;
      canvas.height = state.resolution.height;
    }

    // Render visual frame
    renderCanvasFrame(ctx, canvas.width, canvas.height, state.previewTime, videoDuration, totalStartSec, state);

    // Synchronize preview audio
    if (state.previewPlaying && !state.isGenerating && state.soundEnabled && state.soundEffect !== 'silent') {
      if (curRemaining !== state.lastPreviewSec) {
        state.lastPreviewSec = curRemaining;
        if (curRemaining === 0) {
          playSynthesizedSound(state.soundEffect, { isFinalChime: true, volume: state.soundVolume });
        } else if (curRemaining > 0) {
          playSynthesizedSound(state.soundEffect, { volume: state.soundVolume });
        }
      }
    }

    requestAnimationFrame(tick);
  }

  requestAnimationFrame(tick);
}

// ---------------------------------------------------------------------------
// Full Project Source Code ZIP Exporter
// ---------------------------------------------------------------------------

// Build a standards-compliant ZIP archive without third-party libraries.
// Files are stored without compression so the source download also works offline.
function buildStoredZip(files) {
  const encoder = new TextEncoder();
  const crcTable = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    crcTable[n] = c >>> 0;
  }

  const crc32 = (bytes) => {
    let crc = 0xFFFFFFFF;
    for (let i = 0; i < bytes.length; i++) {
      crc = crcTable[(crc ^ bytes[i]) & 0xFF] ^ (crc >>> 8);
    }
    return (crc ^ 0xFFFFFFFF) >>> 0;
  };

  const concat = (chunks) => {
    const totalLength = chunks.reduce((sum, chunk) => sum + chunk.length, 0);
    const output = new Uint8Array(totalLength);
    let offset = 0;
    for (const chunk of chunks) {
      output.set(chunk, offset);
      offset += chunk.length;
    }
    return output;
  };

  const now = new Date();
  const dosTime = ((now.getHours() & 31) << 11) | ((now.getMinutes() & 63) << 5) | (Math.floor(now.getSeconds() / 2) & 31);
  const dosDate = (((Math.max(1980, now.getFullYear()) - 1980) & 127) << 9) |
    (((now.getMonth() + 1) & 15) << 5) | (now.getDate() & 31);

  const localParts = [];
  const centralParts = [];
  let localOffset = 0;

  for (const file of files) {
    const nameBytes = encoder.encode(file.name);
    const dataBytes = typeof file.content === 'string' ? encoder.encode(file.content) : file.content;
    const checksum = crc32(dataBytes);

    const localHeader = new Uint8Array(30);
    const localView = new DataView(localHeader.buffer);
    localView.setUint32(0, 0x04034B50, true);
    localView.setUint16(4, 20, true);
    localView.setUint16(6, 0x0800, true); // UTF-8 filenames
    localView.setUint16(8, 0, true); // Stored, no compression
    localView.setUint16(10, dosTime, true);
    localView.setUint16(12, dosDate, true);
    localView.setUint32(14, checksum, true);
    localView.setUint32(18, dataBytes.length, true);
    localView.setUint32(22, dataBytes.length, true);
    localView.setUint16(26, nameBytes.length, true);
    localView.setUint16(28, 0, true);

    const centralHeader = new Uint8Array(46);
    const centralView = new DataView(centralHeader.buffer);
    centralView.setUint32(0, 0x02014B50, true);
    centralView.setUint16(4, 20, true);
    centralView.setUint16(6, 20, true);
    centralView.setUint16(8, 0x0800, true);
    centralView.setUint16(10, 0, true);
    centralView.setUint16(12, dosTime, true);
    centralView.setUint16(14, dosDate, true);
    centralView.setUint32(16, checksum, true);
    centralView.setUint32(20, dataBytes.length, true);
    centralView.setUint32(24, dataBytes.length, true);
    centralView.setUint16(28, nameBytes.length, true);
    centralView.setUint16(30, 0, true);
    centralView.setUint16(32, 0, true);
    centralView.setUint16(34, 0, true);
    centralView.setUint16(36, 0, true);
    centralView.setUint32(38, 0, true);
    centralView.setUint32(42, localOffset, true);

    localParts.push(localHeader, nameBytes, dataBytes);
    centralParts.push(centralHeader, nameBytes);
    localOffset += localHeader.length + nameBytes.length + dataBytes.length;
  }

  const centralDirectory = concat(centralParts);
  const localData = concat(localParts);
  const endRecord = new Uint8Array(22);
  const endView = new DataView(endRecord.buffer);
  endView.setUint32(0, 0x06054B50, true);
  endView.setUint16(4, 0, true);
  endView.setUint16(6, 0, true);
  endView.setUint16(8, files.length, true);
  endView.setUint16(10, files.length, true);
  endView.setUint32(12, centralDirectory.length, true);
  endView.setUint32(16, localData.length, true);
  endView.setUint16(20, 0, true);

  return new Blob([localData, centralDirectory, endRecord], { type: 'application/zip' });
}

async function downloadProjectZip() {
  const button = document.getElementById('btnDownloadZip');
  if (button) {
    button.disabled = true;
    button.dataset.originalLabel = button.textContent.trim();
    button.textContent = 'Preparing ZIP…';
  }

  showToast('Preparing all Countdown Studio project files…');

  try {
    const readProjectFile = async (relativePath) => {
      const url = new URL(relativePath, document.baseURI);
      const response = await fetch(url, { cache: 'no-store' });
      if (!response.ok) throw new Error(`Could not read ${relativePath} (${response.status})`);
      return response.text();
    };

    const [htmlFile, cssFile, jsFile, readmeEn, readmeSi, favicon] = await Promise.all([
      readProjectFile('./index.html'),
      readProjectFile('./css/style.css'),
      readProjectFile('./js/app.js'),
      readProjectFile('./README.md'),
      readProjectFile('./README_SI.txt'),
      readProjectFile('./favicon.svg')
    ]);

    const files = [
      { name: 'countdown-studio/index.html', content: htmlFile },
      { name: 'countdown-studio/css/style.css', content: cssFile },
      { name: 'countdown-studio/js/app.js', content: jsFile },
      { name: 'countdown-studio/README.md', content: readmeEn },
      { name: 'countdown-studio/README_SI.txt', content: readmeSi },
      { name: 'countdown-studio/favicon.svg', content: favicon }
    ];

    const zipBlob = buildStoredZip(files);
    const zipUrl = URL.createObjectURL(zipBlob);
    const anchor = document.createElement('a');
    anchor.href = zipUrl;
    anchor.download = 'countdown-studio-source-code.zip';
    anchor.style.display = 'none';
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(zipUrl), 30000);

    showToast('Countdown Studio source ZIP downloaded.');
  } catch (error) {
    console.error('Project ZIP download failed:', error);
    showErrorNotice('Could not package the source files from this location. Download the complete ZIP supplied with this project, or host the whole project folder and try again.');
  } finally {
    if (button) {
      button.disabled = false;
      button.textContent = button.dataset.originalLabel || 'Download Source Code (.ZIP)';
    }
  }
}

// ---------------------------------------------------------------------------
// Toast Notification Utility
// ---------------------------------------------------------------------------
function showToast(message) {
  const existing = document.querySelector('.toast-notice');
  if (existing) existing.remove();

  const toast = document.createElement('div');
  toast.className = 'toast-notice';
  toast.innerHTML = `<span>⚡</span> <span>${message}</span>`;
  document.body.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(8px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3200);
}

// ---------------------------------------------------------------------------
// UI Initialization & Event Bindings
// ---------------------------------------------------------------------------
document.addEventListener('DOMContentLoaded', () => {
  // 1. Time Input Handling
  const timeInput = document.getElementById('timeInput');
  timeInput.addEventListener('input', (e) => {
    const val = e.target.value.trim();
    const sec = parseTimeString(val);
    const isValid = Number.isFinite(sec) && sec > 0;
    timeInput.setAttribute('aria-invalid', String(!isValid));
    if (!isValid) return;

    state.startSeconds = sec;
    state.timeString = val;
    state.previewTime = 0;
    state.lastPreviewSec = -1;
    updateSpecsDisplay();
  });

  document.querySelectorAll('.btn-time-chip[data-time]').forEach(btn => {
    btn.addEventListener('click', () => {
      const val = btn.getAttribute('data-time');
      timeInput.value = val;
      state.startSeconds = parseTimeString(val);
      state.timeString = val;
      state.previewTime = 0;
      state.lastPreviewSec = -1;
      updateSpecsDisplay();
    });
  });

  // 2. Duration Mode Selector
  const modeRealtime = document.getElementById('modeRealtime');
  const modeCompressed = document.getElementById('modeCompressed');
  const customDurationBox = document.getElementById('customDurationBox');
  const outputDurationInput = document.getElementById('outputDurationInput');

  modeRealtime.addEventListener('click', () => {
    state.durationMode = 'realtime';
    modeRealtime.classList.add('active');
    modeCompressed.classList.remove('active');
    customDurationBox.classList.add('hidden');
    state.previewTime = 0;
    state.lastPreviewSec = -1;
    updateSpecsDisplay();
  });

  modeCompressed.addEventListener('click', () => {
    state.durationMode = 'compressed';
    modeCompressed.classList.add('active');
    modeRealtime.classList.remove('active');
    customDurationBox.classList.remove('hidden');
    state.previewTime = 0;
    state.lastPreviewSec = -1;
    updateSpecsDisplay();
  });

  outputDurationInput.addEventListener('input', (e) => {
    const val = Number(e.target.value);
    const isValid = Number.isInteger(val) && val >= 1 && val <= 600;
    outputDurationInput.setAttribute('aria-invalid', String(!isValid));
    if (!isValid) return;

    state.outputDuration = val;
    state.previewTime = 0;
    state.lastPreviewSec = -1;
    updateSpecsDisplay();
  });

  // 3. Template Selection
  const templateCards = document.querySelectorAll('.template-card');
  templateCards.forEach(card => {
    card.addEventListener('click', () => {
      templateCards.forEach(c => c.classList.remove('active'));
      card.classList.add('active');
      state.template = card.getAttribute('data-template');
      updateSpecsDisplay();
    });
  });

  // 4. Background Customization
  const bgPicker = document.getElementById('bgColorPicker');
  const bgHexBadge = document.getElementById('bgHexBadge');

  bgPicker.addEventListener('input', (e) => {
    const hex = e.target.value;
    state.bgColor = hex;
    state.isChromaPreset = (hex.toLowerCase() === '#00ff00');
    bgHexBadge.textContent = hex.toUpperCase();
    updateBgSwatchHighlight(hex);
  });

  document.querySelectorAll('.bg-swatch-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const color = btn.getAttribute('data-color');
      state.bgColor = color;
      state.isChromaPreset = (color.toLowerCase() === '#00ff00');
      bgPicker.value = color;
      bgHexBadge.textContent = color.toUpperCase();
      updateBgSwatchHighlight(color);
    });
  });

  function updateBgSwatchHighlight(color) {
    document.querySelectorAll('.bg-swatch-btn').forEach(b => {
      if (b.getAttribute('data-color').toLowerCase() === color.toLowerCase()) {
        b.classList.add('active');
      } else {
        b.classList.remove('active');
      }
    });
  }

  // 5. Typography & Frame Sliders
  const fontSelect = document.getElementById('fontFamilySelect');
  fontSelect.addEventListener('change', (e) => {
    state.fontFamily = e.target.value;
  });

  bindSlider('scaleSlider', 'scaleVal', (v) => { state.fontScale = parseFloat(v); }, '%');
  bindSlider('frameThickSlider', 'frameThickVal', (v) => { state.frameThickness = parseInt(v, 10); }, 'px');
  bindSlider('radiusSlider', 'radiusVal', (v) => { state.cornerRadius = parseInt(v, 10); }, 'px');
  bindSlider('glowSlider', 'glowVal', (v) => { state.glowIntensity = parseFloat(v); }, 'x');

  const posSelect = document.getElementById('positionSelect');
  posSelect.addEventListener('change', (e) => {
    state.position = e.target.value;
  });

  bindColorPicker('numColorPicker', 'numColorReset', (c) => { state.numColor = c; });
  bindColorPicker('frameColorPicker', 'frameColorReset', (c) => { state.frameColor = c; });
  bindColorPicker('glowColorPicker', 'glowColorReset', (c) => { state.glowColor = c; });

  // 6. Sound Effects & Audio Controls
  const soundToggle = document.getElementById('soundToggle');
  const soundOptionsGrid = document.getElementById('soundOptionsGrid');
  const soundVolumeGroup = document.getElementById('soundVolumeGroup');

  if (soundToggle) {
    soundToggle.addEventListener('change', (e) => {
      state.soundEnabled = e.target.checked;
      if (soundOptionsGrid) {
        soundOptionsGrid.style.opacity = state.soundEnabled ? '1' : '0.45';
        soundOptionsGrid.style.pointerEvents = state.soundEnabled ? 'auto' : 'none';
      }
      if (soundVolumeGroup) {
        soundVolumeGroup.style.opacity = state.soundEnabled ? '1' : '0.45';
        soundVolumeGroup.style.pointerEvents = state.soundEnabled ? 'auto' : 'none';
      }
      updateSpecsDisplay();
    });
  }

  const soundOptionButtons = document.querySelectorAll('.btn-sound-option');
  soundOptionButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      soundOptionButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      state.soundEffect = btn.getAttribute('data-sound');
      updateSpecsDisplay();
      if (state.soundEffect !== 'silent') {
        previewSingleSound();
      }
    });
  });

  const soundVolSlider = document.getElementById('soundVolumeSlider');
  const soundVolVal = document.getElementById('soundVolumeVal');
  if (soundVolSlider && soundVolVal) {
    soundVolSlider.addEventListener('input', (e) => {
      const val = parseInt(e.target.value, 10);
      state.soundVolume = val / 100;
      soundVolVal.textContent = `${val}%`;
      updateSpecsDisplay();
    });
  }

  const btnPreviewSound = document.getElementById('btnPreviewSound');
  if (btnPreviewSound) {
    btnPreviewSound.addEventListener('click', previewSingleSound);
  }

  const btnTestSound = document.getElementById('btnTestSound');
  if (btnTestSound) {
    btnTestSound.addEventListener('click', testCountdownAudioSequence);
  }

  // 7. Resolution & FPS
  const resButtons = document.querySelectorAll('.btn-res');
  resButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      resButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const w = parseInt(btn.getAttribute('data-width'), 10);
      const h = parseInt(btn.getAttribute('data-height'), 10);
      state.resolution = { width: w, height: h, name: `${w}x${h}` };

      const wrapper = document.getElementById('canvasWrapper');
      wrapper.className = 'canvas-wrapper';
      if (w === 1080 && h === 1920) {
        wrapper.classList.add('ratio-vertical');
      } else if (w === h) {
        wrapper.classList.add('ratio-square');
      }

      updateSpecsDisplay();
    });
  });

  const fpsSelect = document.getElementById('fpsSelect');
  fpsSelect.addEventListener('change', (e) => {
    state.fps = parseInt(e.target.value, 10);
    updateSpecsDisplay();
  });

  // 8. Preview Playback Controls
  const btnPlayPause = document.getElementById('btnPlayPause');
  const btnRestart = document.getElementById('btnRestartPreview');
  const scrubSlider = document.getElementById('scrubSlider');

  btnPlayPause.addEventListener('click', () => {
    state.previewPlaying = !state.previewPlaying;
    state.lastPreviewSec = -1;
    btnPlayPause.innerHTML = state.previewPlaying
      ? `<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>`
      : `<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>`;
  });

  btnRestart.addEventListener('click', () => {
    state.previewTime = 0;
    state.lastPreviewSec = -1;
  });

  scrubSlider.addEventListener('input', (e) => {
    state.previewPlaying = false;
    state.lastPreviewSec = -1;
    btnPlayPause.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>`;
    const pct = parseFloat(e.target.value) / 100;
    const dur = state.durationMode === 'compressed' ? state.outputDuration : state.startSeconds;
    state.previewTime = pct * dur;
  });

  // 9. Video Generation & Download
  document.getElementById('btnGenerateVideo').addEventListener('click', generateCountdownVideo);
  document.getElementById('btnCancelGen').addEventListener('click', () => { state.isCancelled = true; });
  document.getElementById('btnDownloadVideo').addEventListener('click', downloadGeneratedVideo);

  const filenameInput = document.getElementById('filenameInput');
  if (filenameInput) {
    filenameInput.addEventListener('input', () => {
      const btnDownload = document.getElementById('btnDownloadVideo');
      if (btnDownload && state.currentVideoUrl) {
        btnDownload.download = getCleanFilename();
      }
    });
  }
  document.getElementById('btnNewVideo').addEventListener('click', () => {
    if (state.currentVideoUrl) {
      URL.revokeObjectURL(state.currentVideoUrl);
      state.currentVideoUrl = null;
    }
    state.currentVideoBlob = null;
    document.getElementById('videoResultCard').classList.remove('active');
    const player = document.getElementById('completedVideoPlayer');
    player.src = '';
    window.scrollTo({ top: 0, behavior: 'smooth' });
    showToast('Ready to configure and generate a new countdown video.');
  });

  // 10. Header Actions
  document.getElementById('btnResetAll').addEventListener('click', resetAllSettings);
  document.getElementById('btnRandomTemplate').addEventListener('click', pickRandomTemplate);
  document.getElementById('btnDownloadZip').addEventListener('click', downloadProjectZip);

  // 11. Sinhala Documentation Modal
  const modal = document.getElementById('sinhalaModal');
  document.getElementById('btnSinhalaGuide').addEventListener('click', () => {
    modal.classList.add('active');
  });
  const footerGuideButton = document.getElementById('footerGuideLink');
  if (footerGuideButton) {
    footerGuideButton.addEventListener('click', () => modal.classList.add('active'));
  }
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') modal.classList.remove('active');
  });
  document.getElementById('modalCloseBtn').addEventListener('click', () => {
    modal.classList.remove('active');
  });
  modal.addEventListener('click', (e) => {
    if (e.target === modal) modal.classList.remove('active');
  });

  updateSpecsDisplay();
  startPreviewLoop();
});

function bindSlider(id, labelId, onChange, unit = '') {
  const slider = document.getElementById(id);
  const label = document.getElementById(labelId);
  slider.addEventListener('input', (e) => {
    const v = e.target.value;
    label.textContent = unit === '%' ? `${Math.round(v * 100)}%` : `${v}${unit}`;
    onChange(v);
  });
}

function bindColorPicker(pickerId, resetBtnId, onChange) {
  const picker = document.getElementById(pickerId);
  const resetBtn = document.getElementById(resetBtnId);
  picker.addEventListener('input', (e) => {
    onChange(e.target.value);
  });
  if (resetBtn) {
    resetBtn.addEventListener('click', () => {
      picker.value = '#ffffff';
      onChange('');
    });
  }
}

function updateSpecsDisplay() {
  const specsRow = document.getElementById('generateSpecsRow');
  const durSec = state.durationMode === 'compressed' ? state.outputDuration : state.startSeconds;
  let hasAudio = state.soundEnabled && state.soundEffect !== 'silent';
  const mime = getBestVideoMimeType(hasAudio);
  const audioLabel = hasAudio ? `🔊 ${state.soundEffect.toUpperCase()} (${Math.round(state.soundVolume * 100)}%)` : '🔇 SILENT';

  specsRow.innerHTML = `
    <span>📐 ${state.resolution.name}</span>
    <span>⚡ ${state.fps} FPS</span>
    <span>⏱️ Duration: ${formatSecondsToDisplay(durSec)}</span>
    <span>🎨 ${state.template.toUpperCase()}</span>
    <span>${audioLabel}</span>
    <span>📦 ${mime.ext.toUpperCase()}</span>
  `;
}

function resetAllSettings() {
  state.startSeconds = 180;
  state.timeString = '03:00';
  state.durationMode = 'compressed';
  state.outputDuration = 10;
  state.template = 'gold';
  state.bgColor = '#00ff00';
  state.isChromaPreset = true;
  state.numColor = '';
  state.frameColor = '';
  state.glowColor = '';
  state.fontFamily = "'Montserrat', sans-serif";
  state.fontScale = 1.0;
  state.frameThickness = 8;
  state.cornerRadius = 24;
  state.glowIntensity = 1.0;
  state.position = 'center';
  state.soundEnabled = true;
  state.soundEffect = 'tick';
  state.soundVolume = 0.8;
  state.resolution = { width: 1920, height: 1080, name: '1920x1080' };
  state.fps = 30;
  state.previewTime = 0;
  state.previewPlaying = true;
  state.lastPreviewSec = -1;

  const playPauseButton = document.getElementById('btnPlayPause');
  if (playPauseButton) {
    playPauseButton.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>';
  }

  const setValue = (id, value) => {
    const element = document.getElementById(id);
    if (element) element.value = value;
  };

  setValue('timeInput', '03:00');
  setValue('outputDurationInput', 10);
  document.getElementById('timeInput').setAttribute('aria-invalid', 'false');
  document.getElementById('outputDurationInput').setAttribute('aria-invalid', 'false');
  setValue('bgColorPicker', '#00ff00');
  setValue('fontFamilySelect', "'Montserrat', sans-serif");
  setValue('scaleSlider', 1.0);
  setValue('frameThickSlider', 8);
  setValue('radiusSlider', 24);
  setValue('glowSlider', 1.0);
  setValue('positionSelect', 'center');
  setValue('numColorPicker', '#ffffff');
  setValue('frameColorPicker', '#ffffff');
  setValue('glowColorPicker', '#ffffff');
  setValue('soundVolumeSlider', 80);
  setValue('fpsSelect', '30');

  const bgHexBadge = document.getElementById('bgHexBadge');
  if (bgHexBadge) bgHexBadge.textContent = '#00FF00';
  const labels = {
    scaleVal: '100%', frameThickVal: '8px', radiusVal: '24px',
    glowVal: '1.0x', soundVolumeVal: '80%'
  };
  Object.entries(labels).forEach(([id, value]) => {
    const element = document.getElementById(id);
    if (element) element.textContent = value;
  });

  const soundToggle = document.getElementById('soundToggle');
  if (soundToggle) soundToggle.checked = true;
  document.querySelectorAll('.btn-sound-option').forEach(button => {
    button.classList.toggle('active', button.getAttribute('data-sound') === 'tick');
  });
  document.querySelectorAll('.btn-res').forEach(button => {
    button.classList.toggle('active', button.getAttribute('data-width') === '1920' && button.getAttribute('data-height') === '1080');
  });
  document.querySelectorAll('.template-card').forEach(card => {
    card.classList.toggle('active', card.getAttribute('data-template') === 'gold');
  });
  document.querySelectorAll('.bg-swatch-btn').forEach(button => {
    button.classList.toggle('active', button.getAttribute('data-color').toLowerCase() === '#00ff00');
  });

  const modeRealtime = document.getElementById('modeRealtime');
  const modeCompressed = document.getElementById('modeCompressed');
  const customDurationBox = document.getElementById('customDurationBox');
  if (modeRealtime) modeRealtime.classList.remove('active');
  if (modeCompressed) modeCompressed.classList.add('active');
  if (customDurationBox) customDurationBox.classList.remove('hidden');

  const canvasWrapper = document.getElementById('canvasWrapper');
  if (canvasWrapper) canvasWrapper.className = 'canvas-wrapper';

  const soundOptionsGrid = document.getElementById('soundOptionsGrid');
  const soundVolumeGroup = document.getElementById('soundVolumeGroup');
  if (soundOptionsGrid) {
    soundOptionsGrid.style.opacity = '1';
    soundOptionsGrid.style.pointerEvents = 'auto';
  }
  if (soundVolumeGroup) {
    soundVolumeGroup.style.opacity = '1';
    soundVolumeGroup.style.pointerEvents = 'auto';
  }

  updateSpecsDisplay();
  showToast('All settings restored to the default studio setup.');
}

function pickRandomTemplate() {
  const templates = ['gold', 'blue', 'pink', 'red', 'chrome', 'purple', 'green', 'led', 'minimal', 'glass'];
  const currentIdx = templates.indexOf(state.template);
  let nextIdx = Math.floor(Math.random() * templates.length);
  if (nextIdx === currentIdx) nextIdx = (currentIdx + 1) % templates.length;

  const chosen = templates[nextIdx];
  state.template = chosen;

  document.querySelectorAll('.template-card').forEach(c => {
    c.classList.toggle('active', c.getAttribute('data-template') === chosen);
  });

  updateSpecsDisplay();
  showToast(`Switched to ${chosen.toUpperCase()} template!`);
}
